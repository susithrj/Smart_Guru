/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow
 * @lint-ignore-every XPLATJSCOPYRIGHT1
 */

import React, {Component} from 'react';
import {


  StyleSheet, 
  View,
  TextInput,
  Dimensions,
  Text, 
  ImageBackground,
  Image,
  TouchableOpacity



}  from 'react-native';

import bgImage from './images/front.jpg'
// import logo from '.../image/logo.png'
import {Actions} from 'react-native-router-flux'


const {width: WIDTH } = Dimensions.get('window')
export default class Home extends Component<> {

  suggestions() {
		Actions.suggestions()
  }
  
  quiz() {
		Actions.quiz()
  }
  
  lessons() {
		Actions.lessons()
	}



  render() {
    return (
     
        
      <ImageBackground source={bgImage} style={styles.backgroundContainer}>
       
       <TouchableOpacity style={styles.btnLogin} onPress={this.lessons}>
           <Text style={styles.text} >Lessons</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.btnLogin} onPress={this.quiz}>
           <Text style={styles.text} >Quiz</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.btnLogin}>
           <Text style={styles.text} >Play with Players</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.btnLogin} onPress={this.suggestions}>
           <Text style={styles.text} >Suggestions</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.btnLogin}>
           <Text style={styles.text} >Recommend Questions</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.btnLogin}>
           <Text style={styles.text} >Profile</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.btnLogin}>
           <Text style={styles.text} >Logout</Text>
        </TouchableOpacity>
      </ImageBackground>
    
    );
  }
}


const styles = StyleSheet.create({
 

  backgroundContainer: {
    flex: 1,
    width: null,
    height:null,
    justifyContent: 'center',
    alignItems: 'center',
  
  },

 

  btnLogin:{

      width: WIDTH - 55,
      height: 45,
      borderRadius: 25,
      backgroundColor: '#432577',
      justifyContent: 'center',
      marginTop: 10

  },

  text: {
      color: 'rgba(255,255,255,0.7)',
      fontSize: 16,
      textAlign: 'center'

  }


  
});


