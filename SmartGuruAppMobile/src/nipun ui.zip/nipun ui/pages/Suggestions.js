import React, { Component } from 'react';
 
import { StyleSheet, ActivityIndicator, ListView, Text, View, Alert,WebView, Platform,Linking } from 'react-native';
 
export default class Suggestions extends Component {
  
  constructor(props) {
 
    super(props);
 
    this.state = {
 
      isLoading: true,
 
    }
 
  }
 
GetItem (links) {
   
  Alert.alert(links);
 
}
 
componentDidMount(){
 
  return fetch('http://192.168.1.103/links/VedioSuggestions.php')
  .then((response) => response.json())
  .then((responseJson) => {
    let ds = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});
    this.setState({
      isLoading: false,
      dataSource: ds.cloneWithRows(responseJson),
    }, function() {
      // In this block you can do something with new state.
    });
  })
  .catch((error) => {
    console.error(error);
  });
 
}
 
  ListViewItemSeparator = () => {
    return (
      <View
        style={{
          height: 2,
          width: "100%",
          backgroundColor: "#000",
        }}
      />
    );
  }
 
  render() {
    if (this.state.isLoading) {
      return (
        <View style={{flex: 1, paddingTop: 20}}>
          <ActivityIndicator />
        
        </View>
      );
    }
 
    return (
 
      <View style={styles.MainContainer}>
 
        <ListView
 
          dataSource={this.state.dataSource}
 
          renderSeparator= {this.ListViewItemSeparator}
 
          enableEmptySections = {true}
 
          renderRow={(rowData) => <Text style={styles.rowViewContainer} 
          onPress={()=> Linking.openURL((this, rowData.links))} >{rowData.links}</Text>}

        //  style={styles.TextStyle} onPress={ ()=> Linking.openURL('https://google.com') }
 
          
        />

{/* <View style={{ height: 300 }}>
 
 <WebView
         style={ styles.WebViewContainer }
         javaScriptEnabled={true}
         domStorageEnabled={true}
         source={{uri: 'https://www.youtube.com/embed/dFKhWe2bBkM' }}
 />

</View> */}
 
{/* <View style={{ height: 240 }}>
        <WebView
          javaScriptEnabled={true}
          domStorageEnabled={true}
          source={{ uri: "https://www.youtube.com/embed/0iayQ1xPsnc" }}

        />
      </View> } */}


 
      </View>
    );
  }
}
 
const styles = StyleSheet.create({
 
MainContainer :{
justifyContent: 'center',
flex:1,
margin: 10
 
},
 
rowViewContainer: {
  fontSize: 20,
  paddingRight: 10,
  paddingTop: 10,
  paddingBottom: 10,
},

WebViewContainer: {
 
  marginTop: (Platform.OS == 'ios') ? 20 : 0,

}
 
});