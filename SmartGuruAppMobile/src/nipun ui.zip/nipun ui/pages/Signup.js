/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow
 * @lint-ignore-every XPLATJSCOPYRIGHT1
 */

import React, {Component} from 'react';
import {

  StyleSheet, 
  Text, 
  View,
  ImageBackground,
  Image,
  TextInput,
  Dimensions,
  TouchableOpacity,
  Alert


}  from 'react-native';

import bgImage from './images/front.jpg'
import logo from './images/logo.png'
import {Actions} from 'react-native-router-flux'


const {width: WIDTH } = Dimensions.get('window')
export default class Signup extends Component<> {

  login() {
		Actions.login()
  }
  



  constructor(props) {
 
    super(props)
 
    this.state = {
 
      TextInputName: '',
      TextInputEmail: '',
      TextInputPassword: ''
 
    }
 
  }
 
  InsertDataToDb = () =>{
 
 
 const { TextInputName }  = this.state ;
 const { TextInputEmail }  = this.state ;
 const { TextInputPassword }  = this.state ;
 
 
//  fetch('https://reactnativecode.000webhostapp.com/submit_user_info.php', {
fetch('http://192.168.1.104/links/UserSignUp.php', {
  method: 'POST',
  headers: {
    'Accept': 'application/json',
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
 
    name: TextInputName,
 
    email: TextInputEmail,
 
    password: TextInputPassword
 
  })
 
}).then((response) => response.json())
      .then((responseJson) => {
 
// Showing response message coming from server after inserting records.
        Alert.alert(responseJson);
 
      }).catch((error) => {
        console.error(error);
      });
 
 
  }







  render() {
    return (
      <ImageBackground source={bgImage} style={styles.backgroundContainer}>
        <View style={styles.logoContainer}>
           <Image source={logo} style={styles.logo} />         
        </View>
        <View>
           <TextInput
              style={styles.inputUsername}
              placeholder={'Username'}
              placeholderTextColor={'rgba(255,255,255,0.7)'}

              onChangeText={TextInputName => this.setState({TextInputName})}

              underlineColorAndroid='transparent'

           />
            <TextInput
              style={styles.inputEmail}
              placeholder={'Email'}
              placeholderTextColor={'rgba(255,255,255,0.7)'}


              onChangeText={TextInputEmail => this.setState({TextInputEmail})}

              underlineColorAndroid='transparent'

           />
           <TextInput
              style={styles.inputPassword}
              placeholder={'Password'}
              secureTextEntry={true}
              placeholderTextColor={'rgba(255,255,255,0.7)'}

              onChangeText={TextInputPassword => this.setState({TextInputPassword})}

              underlineColorAndroid='transparent'

           /> 
           <TextInput
              style={styles.inputPassword}
              placeholder={'Confirm Password'}
              secureTextEntry={true}
              placeholderTextColor={'rgba(255,255,255,0.7)'}
              underlineColorAndroid='transparent'

           />              
        </View>

        <TouchableOpacity style={styles.btnLogin} onPress={this.InsertDataToDb}  >
           <Text style={styles.text} >Confirm</Text>
        </TouchableOpacity>
        <Text style={styles.loginLine}>Already have a account?
           <Text style={styles.text} onPress={this.login}>    Login</Text>
        </Text>
      </ImageBackground>
    );
  }
}


const styles = StyleSheet.create({
  backgroundContainer: {
    flex: 1,
    width: null,
    height:null,
    justifyContent: 'center',
    alignItems: 'center',
  
  },

  logoContainer:{
  alignItems: 'center',
  },

  logo:{
      width:220,
      height:220
  },

  inputUsername:{


      width: WIDTH - 55,
      height: 45,
      borderRadius: 25,
      fontSize: 16,
      paddingLeft: 45,
      backgroundColor: 'rgba(0, 0, 0, 0.35)',
      color: 'rgba(255,255,255,0.7)',
      marginHorizontal: 25
  },

  inputPassword: {

      marginTop: 10,
      width: WIDTH - 55,
      height: 45,
      borderRadius: 25,
      fontSize: 16,
      paddingLeft: 45,
      backgroundColor: 'rgba(0, 0, 0, 0.35)',
      color: 'rgba(255,255,255,0.7)',
      marginHorizontal: 25
  },

  inputEmail: {

    marginTop: 10,
    width: WIDTH - 55,
    height: 45,
    borderRadius: 25,
    fontSize: 16,
    paddingLeft: 45,
    backgroundColor: 'rgba(0, 0, 0, 0.35)',
    color: 'rgba(255,255,255,0.7)',
    marginHorizontal: 25
},

  btnLogin:{

      width: WIDTH - 55,
      height: 45,
      borderRadius: 25,
      backgroundColor: '#432577',
      justifyContent: 'center',
      marginTop: 20

  },

  loginLine:{

    // width: WIDTH - 55,
    // height: 45,
    // borderRadius: 25,
    // backgroundColor: '#432577',
    justifyContent: 'center',
    marginTop: 20,
    fontSize: 16

},

  text: {
      color: 'rgba(255,255,255,0.7)',
      fontSize: 16,
      textAlign: 'center'

  }
  
});


