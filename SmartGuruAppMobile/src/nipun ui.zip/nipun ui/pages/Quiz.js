/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow
 * @lint-ignore-every XPLATJSCOPYRIGHT1
 */

import React, {Component} from 'react';
import {


  StyleSheet, 
  View,
  TextInput,
  Dimensions,
  Text, 
  ImageBackground,
  Image,
  TouchableOpacity,
  ListView,
  ActivityIndicator,
  Platform,
  Linking,
  FlatList



}  from 'react-native';

import bgImage from './images/front.jpg'
// import logo from '.../image/logo.png'
// import {Actions} from 'react-native-router-flux'


const {width: WIDTH } = Dimensions.get('window')
export default class Quiz extends Component {

  constructor(props){
    super(props);
    this.state ={ isLoading: true,
    url: ''
  }
   
  }

  componentDidMount(){
    return fetch('http://127.0.0.1:5000/')
      .then((response) => response.json())
      .then((responseJson) => {

        this.setState({
          url:responseJson[0],
          isLoading: false,
          // dataSource: responseJson.movies,
        }, function(){

        });

      })
      .catch((error) =>{
        console.error(error);
      });
  }



  render(){

    if(this.state.isLoading){
      return(
        <View style={{flex: 1, padding: 20}}>
          <ActivityIndicator/>
        </View>
      )
    }

    return(
      <View style={{flex: 1, paddingTop:20}}>   
       <Text>{this.state.url}</Text>
      </View>
    );
  }
}


const styles = StyleSheet.create({
 

  backgroundContainer: {
    flex: 1,
    width: null,
    height:null,
    justifyContent: 'center',
    alignItems: 'center',
  
  },

 

  btnLogin:{

      width: WIDTH - 55,
      height: 45,
      borderRadius: 25,
      backgroundColor: '#432577',
      justifyContent: 'center',
      marginTop: 10

  },

  text: {
      color: 'rgba(255,255,255,0.7)',
      fontSize: 16,
      textAlign: 'center'

  }


  
});


