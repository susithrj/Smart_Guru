import React, { Component } from 'react';
import {Router, Stack, Scene} from 'react-native-router-flux';

import Login from './pages/Login';
import Signup from './pages/Signup';
import Home from './pages/Home';
import Suggestions from './pages/Suggestions';
import Quiz from './pages/Quiz';
import Lessons from './pages/Lessons';

export default class Routes extends Component<> {
	render() {
		return(
			<Router>
			    <Stack key="root" hideNavBar={true}>		
					  <Scene key="login" component={Login} title="Login" initial={true}/>
						<Scene key="signup" component={Signup} title="Signup"/>
						<Scene key="home" component={Home} title="Home"/>
						<Scene key="suggestions" component={Suggestions} title="Suggestions"/>
						<Scene key="quiz" component={Quiz} title="Quiz"/>
						<Scene key="lessons" component={Lessons} title="Lessons"/>
			    </Stack>
			 </Router>
			)
	}
}